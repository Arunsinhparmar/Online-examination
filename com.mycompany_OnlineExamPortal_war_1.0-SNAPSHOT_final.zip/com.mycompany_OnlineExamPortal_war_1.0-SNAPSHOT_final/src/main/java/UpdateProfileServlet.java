/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam_portal", "root", "password");
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET name = ?, email = ? WHERE user_id = ?");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, userId);
            ps.executeUpdate();

            response.sendRedirect("dashboard.jsp");  // Redirect back to dashboard
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
