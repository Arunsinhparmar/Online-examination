/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdatePasswordServlet extends HttpServlet {
    protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String currentPassword = request.getParameter("current_password");
        String newPassword = request.getParameter("new_password");

        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam_portal", "root", "password");
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET password = ? WHERE user_id = ? AND password = ?");
            ps.setString(1, newPassword);
            ps.setString(2, userId);
            ps.setString(3, currentPassword);
            int rowCount = ps.executeUpdate();

            if (rowCount > 0) {
                response.sendRedirect("dashboard.jsp");  
            } else {
              
                response.getWriter().println("Current password is incorrect.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
