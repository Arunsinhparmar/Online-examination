package com.mycompany.onlineexamportal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExamDAO {
    private Connection conn;

    public ExamDAO() throws SQLException, ClassNotFoundException {
        conn = DBConnection.getConnection(); // Make sure this method works correctly
    }

    public List<Exam> getAllExams() throws SQLException {
        List<Exam> exams = new ArrayList<>();
        String query = "SELECT exam_id, title, description, exam_date FROM exams";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                int examId = rs.getInt("exam_id");
                String title = rs.getString("title");
                String description = rs.getString("description");
                Date examDate = rs.getDate("exam_date"); // Ensure you handle Date correctly
                exams.add(new Exam(examId, title, description, examDate));
            }
        }
System.out.println("Retrieved exams: " + exams);

        return exams;
    }
}
