package com.mycompany.onlineexamportal;

import com.mycompany.onlineexamportal.Exam;
import com.mycompany.onlineexamportal.ExamDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewExams")
public class ViewExamServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Exam> exams = null;

        try {
            ExamDAO examDAO = new ExamDAO();
            exams = examDAO.getAllExams(); // Fetch exams from the database
            
            // Print exams to console for debugging
            System.out.println("Exams fetched: " + exams);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Log any exceptions
        }

        request.setAttribute("exams", exams); // Set the list of exams in the request
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewExams.jsp");
        dispatcher.forward(request, response);
    }
}
