/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.onlineexamportal;

import java.util.Date;

public class Exam {
    private int examId;
    private String title;
    private String description;
    private Date examDate;

    // Constructor
    public Exam(int examId, String title, String description, Date examDate) {
        this.examId = examId;
        this.title = title;
        this.description = description;
        this.examDate = examDate;
    }

    // Getters
    public int getExamId() {
        return examId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Date getExamDate() {
        return examDate;
    }
}
